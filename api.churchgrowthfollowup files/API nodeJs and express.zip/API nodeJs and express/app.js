const express = require('express');

let app =express();
app.get('/',(req,res)=>{
res.status(200)
.json({message:'hello from the server side',app:'Natours'});
});

app.post('/',(req,res)=>{
  res.send('you are welcome to post in this api');
});

app.listen(3000,()=>{
    console.log("We are listening");
});
