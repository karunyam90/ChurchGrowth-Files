const { ok } = require('assert');
const express = require('express');
const mysql = require('mysql');
const fs = require("fs");
const app =express();
const port = 3100;
//Middleware for JSON to post in API .This middleware stands between the request and the Response
app.use(express.json());
//Creating an SQL Connection
var connection = mysql.createConnection({
//properties
  host : 'ls-ed397ff2bb830a9a7dfa6d03200cf165761617ed.c2rsgppn70pe.ap-south-1.rds.amazonaws.com',
  port:3306,
  user :'dbmasteruser',
  password : 'DanielJoel90',
  database:'bitnami_wordpress'
});


app.get('/api/v1/believers',(req,res)=>{
  let sql ="select * from bitnami_wordpress.wp_newbeleiver";
  let count = 0;
  connection.query(sql,(err,result)=>{
    if(err) throw err;
    console.log(result)
    res.send(result);
  });
});

//Post The data in the API
app.post('/api/v1/believers',(req,res)=>{
  let sql ="update bitnami_wordpress.wp_newbeleiver set count = 0";
  connection.query(sql,(err,result)=>{
    if(err) throw err;
    res.send(result);
  });
 
});
//Patch the Data in the API

app.patch('/api/v1/believers/:id',(req,res)=>{
  let sql =`update bitnami_wordpress.wp_newbeleiver set count = count +1 where id=${req.params.id}`;
  connection.query(sql,(err,result)=>{
    if(err) throw err;
    res.send(result);
  });
});

//Get the parameters passed through the API
app.get('/api/v1/believers/:userid',(req,res)=>{
  let sql =`select * from bitnami_wordpress.wp_newbeleiver where user_id=${req.params.userid}`;
  connection.query(sql,(err,result)=>{
    if(err) throw err;
    res.send(result);
  });
}); 


//Get the parameters passed through API part 2
app.get('/api/v1/believers/:name',(req,res)=>{
  console.log(req.params);
  res.send("done");
});

app.listen(port);